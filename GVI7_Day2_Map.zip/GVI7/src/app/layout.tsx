import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "../styles/globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "GeoVisual Intelligence",
  description: "AI-Powered Global Geopolitical Mapping & Stock Market Analysis",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-navy-dark text-white min-h-screen`}>
        {children}
      </body>
    </html>
  );
}
