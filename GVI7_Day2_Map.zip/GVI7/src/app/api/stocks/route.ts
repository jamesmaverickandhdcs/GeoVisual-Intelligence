import { NextResponse } from "next/server";
import { getDefaultMarketData } from "@/lib/yahoo-finance/quotes";

export async function GET() {
  try {
    const quotes = await getDefaultMarketData();
    return NextResponse.json({ quotes });
  } catch (err) {
    console.error("Stocks error:", err);
    return NextResponse.json({ error: "Failed to fetch market data" }, { status: 500 });
  }
}
