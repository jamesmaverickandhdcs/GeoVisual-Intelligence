import dynamic from "next/dynamic";

// Dynamic import to avoid SSR issues with Canvas
const GeoMap = dynamic(() => import("@/components/map/GeoMap"), {
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center h-full">
      <div className="text-gold animate-pulse text-lg">Loading map...</div>
    </div>
  ),
});

export default function MapPage() {
  return (
    <div className="flex flex-col h-screen bg-navy-dark">
      {/* Navbar */}
      <nav className="flex items-center justify-between px-6 py-3 border-b border-gold/20 bg-navy-dark/95 backdrop-blur z-50">
        <div className="flex items-center gap-3">
          <span className="text-2xl">🌐</span>
          <div>
            <h1 className="text-gold font-bold text-lg leading-none tracking-tight">
              GeoVisual Intelligence
            </h1>
            <p className="text-gray-500 text-xs">v7.0 · HDCS Geeks</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <a href="/map"       className="text-gold text-sm font-semibold border-b border-gold pb-0.5">Map</a>
          <a href="/dashboard" className="text-gray-400 text-sm hover:text-white transition">Dashboard</a>
          <a href="/auth"      className="text-gray-400 text-sm hover:text-white transition">Login</a>
        </div>
      </nav>

      {/* Map fills remaining height */}
      <div className="flex-1 relative overflow-hidden">
        <GeoMap />
      </div>
    </div>
  );
}
