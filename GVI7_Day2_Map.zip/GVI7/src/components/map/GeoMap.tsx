"use client";

import { useEffect, useRef, useState } from "react";
import type { NewsArticle } from "@/types";

// ── Dummy news data for Day 2 demo ──────────────────────────────────────────
const DEMO_NEWS: NewsArticle[] = [
  {
    id: "1", title: "US-China Trade Tensions Escalate",
    summary_short: "New tariffs announced on semiconductor exports. Markets react sharply. Diplomatic talks scheduled for next week.",
    summary_long: "", source: "Reuters", source_url: "https://reuters.com",
    country_code: "US", country_name: "United States",
    latitude: 38.9, longitude: -77.0,
    published_at: new Date().toISOString(), category: "economy",
    sentiment: "negative", created_at: new Date().toISOString(),
  },
  {
    id: "2", title: "Russia-Ukraine Ceasefire Talks Resume",
    summary_short: "Delegations met in Istanbul for the first time in months. Limited progress on prisoner exchanges. Next round set for March.",
    summary_long: "", source: "BBC", source_url: "https://bbc.com",
    country_code: "UA", country_name: "Ukraine",
    latitude: 50.4, longitude: 30.5,
    published_at: new Date().toISOString(), category: "conflict",
    sentiment: "neutral", created_at: new Date().toISOString(),
  },
  {
    id: "3", title: "Middle East Oil Supply Cut Extended",
    summary_short: "OPEC+ confirms production cuts through Q3. Brent crude rises 4%. Global inflation fears renewed.",
    summary_long: "", source: "Al Jazeera", source_url: "https://aljazeera.com",
    country_code: "SA", country_name: "Saudi Arabia",
    latitude: 24.7, longitude: 46.7,
    published_at: new Date().toISOString(), category: "economy",
    sentiment: "negative", created_at: new Date().toISOString(),
  },
  {
    id: "4", title: "EU Signs Historic Climate Agreement",
    summary_short: "27 member states commit to carbon neutrality by 2040. Green energy investments surge. Applauded by UN.",
    summary_long: "", source: "CNN", source_url: "https://cnn.com",
    country_code: "DE", country_name: "Germany",
    latitude: 52.5, longitude: 13.4,
    published_at: new Date().toISOString(), category: "diplomacy",
    sentiment: "positive", created_at: new Date().toISOString(),
  },
  {
    id: "5", title: "India-Pakistan Border Tensions Rise",
    summary_short: "Military buildup reported along Line of Control. Both governments issue statements. UN calls for restraint.",
    summary_long: "", source: "The Hindu", source_url: "https://thehindu.com",
    country_code: "IN", country_name: "India",
    latitude: 28.6, longitude: 77.2,
    published_at: new Date().toISOString(), category: "conflict",
    sentiment: "negative", created_at: new Date().toISOString(),
  },
  {
    id: "6", title: "Japan Economy Grows 2.8% in Q1",
    summary_short: "Strongest quarterly growth in three years. Export-driven recovery supported by weak yen. BOJ signals rate review.",
    summary_long: "", source: "Nikkei", source_url: "https://nikkei.com",
    country_code: "JP", country_name: "Japan",
    latitude: 35.7, longitude: 139.7,
    published_at: new Date().toISOString(), category: "economy",
    sentiment: "positive", created_at: new Date().toISOString(),
  },
];

const SENTIMENT_COLORS: Record<string, string> = {
  positive: "#4CAF50",
  neutral:  "#C9A227",
  negative: "#EF4444",
};

const CATEGORY_ICONS: Record<string, string> = {
  politics:  "🏛️",
  economy:   "📈",
  conflict:  "⚔️",
  diplomacy: "🤝",
  other:     "📰",
};

interface TooltipState {
  article: NewsArticle;
  x: number;
  y: number;
}

export default function GeoMap() {
  const canvasRef   = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [tooltip, setTooltip]   = useState<TooltipState | null>(null);
  const [selected, setSelected] = useState<NewsArticle | null>(null);
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  // Simple equirectangular projection
  function project(lat: number, lng: number, w: number, h: number) {
    const x = ((lng + 180) / 360) * w;
    const y = ((90  - lat)  / 180) * h;
    return { x, y };
  }

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;

    // ── Background ──────────────────────────────────────────────────────────
    ctx.fillStyle = "#0F1F33";
    ctx.fillRect(0, 0, W, H);

    // ── Grid lines ──────────────────────────────────────────────────────────
    ctx.strokeStyle = "rgba(200,162,39,0.08)";
    ctx.lineWidth = 0.5;
    for (let lat = -60; lat <= 60; lat += 30) {
      const { y } = project(lat, 0, W, H);
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }
    for (let lng = -150; lng <= 180; lng += 30) {
      const { x } = project(0, lng, W, H);
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    }

    // ── Equator & Prime Meridian highlight ──────────────────────────────────
    ctx.strokeStyle = "rgba(200,162,39,0.18)";
    ctx.lineWidth = 1;
    const eq = project(0, 0, W, H);
    ctx.beginPath(); ctx.moveTo(0, eq.y); ctx.lineTo(W, eq.y); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(eq.x, 0); ctx.lineTo(eq.x, H); ctx.stroke();

    // ── Continent outlines (simplified polygons) ─────────────────────────────
    const continents = [
      // North America
      [[70,-140],[60,-140],[50,-125],[35,-120],[25,-105],[20,-87],[25,-80],[35,-75],[45,-60],[55,-60],[65,-70],[70,-85],[70,-100],[70,-140]],
      // South America
      [[12,-72],[5,-60],[0,-50],[-15,-39],[-34,-58],[-55,-68],[-55,-65],[-40,-62],[-20,-40],[-5,-35],[10,-62],[12,-72]],
      // Europe
      [[71,28],[68,18],[60,5],[50,-5],[44,-9],[36,-6],[36,10],[42,28],[48,40],[55,37],[60,28],[65,25],[71,28]],
      // Africa
      [[37,10],[30,32],[20,37],[10,42],[0,42],[-10,40],[-35,27],[-34,18],[-22,14],[-10,13],[5,2],[10,-15],[20,-17],[30,-10],[37,10]],
      // Asia
      [[70,30],[60,30],[55,37],[45,38],[35,35],[25,55],[20,60],[10,75],[0,100],[10,105],[20,110],[35,120],[45,135],[55,135],[65,140],[70,140],[70,100],[70,60],[70,30]],
      // Australia
      [[-15,130],[-20,138],[-28,153],[-38,146],[-37,140],[-32,115],[-22,113],[-15,130]],
    ];

    ctx.fillStyle   = "rgba(30,58,95,0.85)";
    ctx.strokeStyle = "rgba(200,162,39,0.35)";
    ctx.lineWidth   = 0.8;

    continents.forEach(poly => {
      ctx.beginPath();
      poly.forEach(([lat, lng], i) => {
        const { x, y } = project(lat, lng, W, H);
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      });
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    });

    // ── News pins ────────────────────────────────────────────────────────────
    DEMO_NEWS.forEach(article => {
      const { x, y } = project(article.latitude, article.longitude, W, H);
      const color   = SENTIMENT_COLORS[article.sentiment];
      const isHover = hoveredId === article.id;
      const r       = isHover ? 10 : 7;

      // Glow
      const glow = ctx.createRadialGradient(x, y, 0, x, y, r * 2.5);
      glow.addColorStop(0, color + "55");
      glow.addColorStop(1, "transparent");
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(x, y, r * 2.5, 0, Math.PI * 2);
      ctx.fill();

      // Pin circle
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = isHover ? 2 : 1;
      ctx.stroke();

      // Pulse ring when hovered
      if (isHover) {
        ctx.beginPath();
        ctx.arc(x, y, r + 5, 0, Math.PI * 2);
        ctx.strokeStyle = color + "88";
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    });
  }, [hoveredId]);

  function handleMouseMove(e: React.MouseEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mx = (e.clientX - rect.left) * (canvas.width  / rect.width);
    const my = (e.clientY - rect.top)  * (canvas.height / rect.height);

    let found: NewsArticle | null = null;
    for (const article of DEMO_NEWS) {
      const { x, y } = project(article.latitude, article.longitude, canvas.width, canvas.height);
      const dist = Math.sqrt((mx - x) ** 2 + (my - y) ** 2);
      if (dist < 14) { found = article; break; }
    }

    if (found) {
      setHoveredId(found.id);
      setTooltip({ article: found, x: e.clientX, y: e.clientY });
    } else {
      setHoveredId(null);
      setTooltip(null);
    }
  }

  function handleClick(e: React.MouseEvent<HTMLCanvasElement>) {
    if (tooltip) setSelected(tooltip.article);
  }

  return (
    <div ref={containerRef} className="relative w-full h-full select-none">
      {/* Map canvas */}
      <canvas
        ref={canvasRef}
        width={1400}
        height={700}
        className="w-full h-full cursor-crosshair"
        onMouseMove={handleMouseMove}
        onMouseLeave={() => { setHoveredId(null); setTooltip(null); }}
        onClick={handleClick}
        style={{ imageRendering: "crisp-edges" }}
      />

      {/* Tooltip */}
      {tooltip && !selected && (
        <div
          className="pointer-events-none fixed z-50 max-w-xs"
          style={{ left: tooltip.x + 14, top: tooltip.y - 10 }}
        >
          <div className="bg-navy-dark border border-gold/40 rounded-xl p-3 shadow-2xl backdrop-blur">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-lg">{CATEGORY_ICONS[tooltip.article.category]}</span>
              <span className="text-gold text-xs font-semibold uppercase tracking-wider">
                {tooltip.article.country_name}
              </span>
              <span
                className="ml-auto text-xs px-2 py-0.5 rounded-full font-bold"
                style={{ background: SENTIMENT_COLORS[tooltip.article.sentiment] + "33", color: SENTIMENT_COLORS[tooltip.article.sentiment] }}
              >
                {tooltip.article.sentiment}
              </span>
            </div>
            <p className="text-white text-sm font-semibold leading-snug mb-1">
              {tooltip.article.title}
            </p>
            <p className="text-gray-400 text-xs leading-relaxed">
              {tooltip.article.summary_short}
            </p>
            <p className="text-gold/60 text-xs mt-2">Click to read more →</p>
          </div>
        </div>
      )}

      {/* Detail panel */}
      {selected && (
        <div className="absolute right-4 top-4 w-80 bg-navy-dark/95 border border-gold/30 rounded-2xl p-5 shadow-2xl backdrop-blur z-40">
          <button
            onClick={() => setSelected(null)}
            className="absolute top-3 right-3 text-gray-400 hover:text-white text-lg leading-none"
          >✕</button>
          <div className="flex items-center gap-2 mb-3">
            <span className="text-2xl">{CATEGORY_ICONS[selected.category]}</span>
            <div>
              <p className="text-gold text-xs font-bold uppercase tracking-widest">{selected.country_name}</p>
              <p className="text-gray-400 text-xs">{selected.source}</p>
            </div>
          </div>
          <h3 className="text-white font-bold text-base leading-snug mb-3">{selected.title}</h3>
          <p className="text-gray-300 text-sm leading-relaxed mb-4">{selected.summary_short}</p>
          <div className="flex items-center justify-between">
            <span
              className="text-xs px-3 py-1 rounded-full font-bold"
              style={{ background: SENTIMENT_COLORS[selected.sentiment] + "22", color: SENTIMENT_COLORS[selected.sentiment] }}
            >
              {selected.sentiment}
            </span>
            <a
              href={selected.source_url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-gold hover:text-gold-light underline"
            >
              Full article →
            </a>
          </div>
        </div>
      )}

      {/* Legend */}
      <div className="absolute bottom-4 left-4 bg-navy-dark/80 border border-gold/20 rounded-xl px-4 py-3 backdrop-blur">
        <p className="text-gold text-xs font-bold mb-2 uppercase tracking-widest">Sentiment</p>
        {[["positive","#4CAF50"],["neutral","#C9A227"],["negative","#EF4444"]].map(([label, color]) => (
          <div key={label} className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: color }} />
            <span className="text-gray-300 text-xs capitalize">{label}</span>
          </div>
        ))}
      </div>

      {/* News count badge */}
      <div className="absolute top-4 left-4 bg-gold/10 border border-gold/30 rounded-xl px-4 py-2 backdrop-blur">
        <p className="text-gold text-xs font-bold">{DEMO_NEWS.length} Active Events</p>
      </div>
    </div>
  );
}
